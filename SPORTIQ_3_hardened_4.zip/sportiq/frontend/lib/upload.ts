import "server-only";
import { randomBytes } from "node:crypto";
import { mkdirSync, writeFileSync } from "node:fs";
import path from "node:path";
import sharp from "sharp";

const MAX = 4 * 1024 * 1024;

/** Checks the real file signature, then decodes and re-encodes the image (drops metadata, rejects non-images, caps size). */
async function cleanImage(file: File): Promise<Buffer> {
  if (file.size === 0) throw new Error("No file selected.");
  if (file.size > MAX) throw new Error("Image is larger than 4 MB.");
  const buf = Buffer.from(await file.arrayBuffer());
  let ext: string | null = null;
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) ext = "jpg";
  else if (buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) ext = "png";
  else if (buf.subarray(0, 4).toString("ascii") === "RIFF" && buf.subarray(8, 12).toString("ascii") === "WEBP") ext = "webp";
  if (!ext) throw new Error("Only JPG, PNG or WebP images are allowed.");
  // Decode and re-encode: drops metadata (GPS etc.), rejects files that are not really images, caps size for fast mobile loading.
  let out: Buffer;
  try {
    out = await sharp(buf, { limitInputPixels: 40_000_000 }).rotate().resize({ width: 1600, height: 1600, fit: "inside", withoutEnlargement: true }).webp({ quality: 82 }).toBuffer();
  } catch {
    throw new Error("That file could not be read as an image.");
  }
  return out;
}

/** Saves an uploaded image for public use (product photos, reviews). Returns the public URL. */
export async function saveImage(file: File): Promise<string> {
  const out = await cleanImage(file);
  const ext = "webp";
  const dir = path.join(process.cwd(), "data", "uploads");
  mkdirSync(dir, { recursive: true });
  const name = `${randomBytes(16).toString("hex")}.${ext}`;
  writeFileSync(path.join(dir, name), out);
  return `/uploads/${name}`;
}

/**
 * Payment receipt photos are private: stored outside the public uploads folder with a random name, and only served
 * to a logged-in staff member by /admin/proof/[name]. Returns the stored file name (not a URL).
 */
export async function savePrivateProof(file: File): Promise<string> {
  const out = await cleanImage(file);
  const dir = path.join(process.cwd(), "data", "private", "proofs");
  mkdirSync(dir, { recursive: true });
  const name = `${randomBytes(16).toString("hex")}.webp`;
  writeFileSync(path.join(dir, name), out);
  return name;
}
