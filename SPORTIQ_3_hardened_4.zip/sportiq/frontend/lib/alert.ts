import "server-only";

/**
 * Optional owner alerts. Set ALERT_WEBHOOK_URL to a Slack/Discord-compatible or ntfy.sh URL and security events
 * (failed logins, lockouts, payment mismatches) are pushed to your phone. Never throws, never blocks the request for long.
 */
export async function alertOwner(text: string) {
  const url = process.env.ALERT_WEBHOOK_URL;
  if (!url) return;
  try {
    await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text: `[SPORTIQ] ${text}`.slice(0, 500), content: `[SPORTIQ] ${text}`.slice(0, 500) }),
      signal: AbortSignal.timeout(4000),
    });
  } catch {
    /* alerting must never break the site */
  }
}
