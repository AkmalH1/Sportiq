import "server-only";
import type { Handle } from "./db";
import { SCHEMA } from "./schema";
import { DEFAULT_BANNERS, DEFAULT_COLLECTIONS, DEFAULT_FAQS, DEFAULT_SPORTS, DEFAULT_ZONES, SUB_CHARTS } from "./starter/content";
import { SETTING_DEFAULTS } from "./settings-defaults";
import { seedDemo } from "./starter/demo";

type Migration = { id: number; name: string; up: (d: Handle) => Promise<void> };

const slugify = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");

/**
 * Ordered, append-only list. Each migration runs once and is recorded in schema_migrations.
 * To change the database after launch, add a new entry at the end. Never edit one that has already shipped.
 */
const MIGRATIONS: Migration[] = [
  {
    id: 1,
    name: "initial schema",
    up: async (d) => {
      for (const sql of SCHEMA) await d.exec(sql.replace(/^CREATE TABLE/, "CREATE TABLE IF NOT EXISTS")); // safe to re-run if a previous start was interrupted
    },
  },
  {
    id: 2,
    name: "starter content (editable in admin afterwards)",
    up: async (d) => {
      for (const [k, v] of Object.entries(SETTING_DEFAULTS)) await d.prepare("INSERT INTO settings (`key`, value) VALUES (?, ?)").run(k, v);
      for (const [i, s] of DEFAULT_SPORTS.entries()) {
        await d.prepare("INSERT INTO sports (slug,name,tagline,accent,sort,size_set,size_chart) VALUES (?,?,?,?,?,?,?)")
          .run(s.slug, s.name, s.tagline, s.accent, i, s.sizeSet ?? "apparel", s.sizeChart ?? "");
        for (const [j, n] of s.subs.entries()) {
          const slug = slugify(n);
          await d.prepare("INSERT INTO subcategories (sport_slug,slug,name,sort,size_chart) VALUES (?,?,?,?,?)").run(s.slug, slug, n, j, SUB_CHARTS[`${s.slug}/${slug}`] ?? "");
        }
      }
      for (const [i, z] of DEFAULT_ZONES.entries()) {
        await d.prepare("INSERT INTO shipping_zones (name,countries,first_kg_lkr,extra_kg_lkr,days,sort) VALUES (?,?,?,?,?,?)").run(z.name, z.countries, z.first, z.extra, z.days, i);
      }
      for (const [i, c] of DEFAULT_COLLECTIONS.entries()) {
        await d.prepare("INSERT INTO collections (slug,name,blurb,from_color,to_color,match_type,sort) VALUES (?,?,?,?,?,?,?)").run(c.slug, c.name, c.blurb, c.from, c.to, c.match, i);
      }
      for (const [i, f] of DEFAULT_FAQS.entries()) await d.prepare("INSERT INTO faqs (question,answer,sort) VALUES (?,?,?)").run(f.q, f.a, i);
      for (const [i, b] of DEFAULT_BANNERS.entries()) {
        await d.prepare("INSERT INTO banners (`position`,sort,eyebrow,title,body,cta_label,cta_href,from_color,to_color) VALUES (?,?,?,?,?,?,?,?,?)")
          .run(b.position, i, b.eyebrow, b.title, b.body, b.cta_label, b.cta_href, b.from, b.to);
      }
    },
  },
  {
    id: 3,
    name: "payments: purpose, received amount, verification trail, private proofs, idempotent orders, reconciliation",
    up: async (d) => {
      // Additive only: no existing order, payment or customer row is changed except new metadata columns being filled in.
      await d.exec(`ALTER TABLE payments
        ADD COLUMN purpose VARCHAR(12) NOT NULL DEFAULT 'full',
        ADD COLUMN received_amount INT NULL,
        ADD COLUMN verified_at DATETIME NULL,
        ADD COLUMN verification_source VARCHAR(24) NOT NULL DEFAULT '',
        ADD COLUMN proof_file VARCHAR(80) NULL`);
      await d.exec("ALTER TABLE payment_events ADD COLUMN payment_id INT NULL, ADD KEY pe_payment (payment_id)");
      await d.exec(`ALTER TABLE orders
        ADD COLUMN idempotency_key VARCHAR(64) NULL,
        ADD COLUMN balance_method VARCHAR(20) NOT NULL DEFAULT '',
        ADD UNIQUE KEY orders_idem (idempotency_key)`);
      await d.exec(`CREATE TABLE reconciliation_items (
        id INT AUTO_INCREMENT PRIMARY KEY,
        order_id INT NOT NULL,
        payment_id INT NULL,
        kind VARCHAR(20) NOT NULL,
        amount INT NOT NULL DEFAULT 0,
        detail VARCHAR(300) NOT NULL DEFAULT '',
        status VARCHAR(12) NOT NULL DEFAULT 'open',
        resolution VARCHAR(20) NOT NULL DEFAULT '',
        resolution_note VARCHAR(300) NOT NULL DEFAULT '',
        refund_ref VARCHAR(100) NOT NULL DEFAULT '',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        resolved_at DATETIME NULL,
        resolved_by VARCHAR(60) NULL,
        KEY recon_status (status),
        KEY recon_order (order_id),
        CONSTRAINT chk_recon_status CHECK (status IN ('open','resolved')),
        CONSTRAINT fk_recon_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
      )`);
      // Existing successful payments: record how they were verified (metadata only, amounts are never touched).
      await d.exec(`UPDATE payments SET received_amount = amount, verified_at = updated_at,
        verification_source = CASE provider WHEN 'payhere' THEN 'notify' WHEN 'bank' THEN 'staff' WHEN 'cash' THEN 'staff' ELSE 'system' END
        WHERE status = 'success' AND received_amount IS NULL`);
      for (const [k, v] of [["deposit_percent", "50"], ["balance_methods", "cash_pickup,cash_delivery,bank,online"], ["balance_note", "The balance is due before your order is handed over or delivered."]]) {
        await d.prepare("INSERT INTO settings (`key`, value) VALUES (?, ?) ON DUPLICATE KEY UPDATE `key` = `key`").run(k, v);
      }
    },
  },
  {
    id: 4,
    name: "atomic rate-limit counters",
    up: async (d) => {
      await d.exec("CREATE TABLE IF NOT EXISTS rate_limits (k VARCHAR(120) NOT NULL PRIMARY KEY, n INT NOT NULL, reset_at BIGINT NOT NULL, KEY rl_reset (reset_at))");
    },
  },
];

export async function runMigrations(d: Handle) {
  await d.exec("CREATE TABLE IF NOT EXISTS schema_migrations (id INT PRIMARY KEY, name VARCHAR(120) NOT NULL, applied_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP)");
  const done = new Set(((await d.prepare("SELECT id FROM schema_migrations").all()) as { id: number }[]).map((r) => r.id));
  for (const m of MIGRATIONS) {
    if (done.has(m.id)) continue;
    await d.exec("START TRANSACTION");
    try {
      await m.up(d);
      await d.prepare("INSERT INTO schema_migrations (id, name) VALUES (?, ?)").run(m.id, m.name);
      await d.exec("COMMIT");
    } catch (e) {
      await d.exec("ROLLBACK").catch(() => {});
      throw e;
    }
    console.log(`[db] applied migration ${m.id}: ${m.name}`);
  }
  // Demo products are opt-in and only ever added to a catalogue that is still empty.
  if (process.env.SEED_DEMO_DATA === "true") {
    const n = (await d.prepare("SELECT COUNT(*) AS n FROM products").get()) as { n: number };
    if (n.n === 0) await seedDemo(d);
  }
}
