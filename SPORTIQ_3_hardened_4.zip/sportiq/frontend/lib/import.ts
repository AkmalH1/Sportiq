import "server-only";
import { audit, db, tx } from "./db";
import { parseCsv } from "./csv";
import { SIZES, sizesFor, skuSuffix, stockColumn } from "./config";
import { sportSlugs as listSportSlugs } from "./categories";

export const CSV_HEADERS = [
  "slug", "name", "sport", "type", "version", "price_lkr", "description", "status",
  "preorder_enabled", "preorder_eta", "image_url", "sku_prefix", "subcategory", "league", "customizable", "weight_g",
  ...SIZES.map((s) => `stock_${s}`), "stock_ONE",
] as const;

export const CSV_TEMPLATE =
  CSV_HEADERS.join(",") +
  "\n" +
  [
    "nba-sample-jersey", "Sample NBA Jersey", "nba", "Jersey", "Swingman Style", "4900", '"Sample description, with a comma"',
    "published", "yes", "Arrives in 2 to 3 weeks", "", "NBA-SMP", "jerseys", "", "no", "400", "0", "2", "3", "1", "0", "0", "0",
  ].join(",") +
  "\n";

export type ImportResult = {
  ok: boolean;
  created: number;
  updated: number;
  errors: { row: number; message: string }[];
};

const yes = (s: string) => ["yes", "y", "true", "1"].includes(s.trim().toLowerCase());
const SLUG = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;

export async function importProductsCsv(text: string, actor: string): Promise<ImportResult> {
  const rows = parseCsv(text);
  const result: ImportResult = { ok: false, created: 0, updated: 0, errors: [] };
  if (rows.length < 2) {
    result.errors.push({ row: 0, message: "The file has no data rows." });
    return result;
  }
  const header = rows[0].map((h) => h.trim().toLowerCase());
  for (const required of ["slug", "name", "sport", "price_lkr", "sku_prefix"]) {
    if (!header.includes(required)) {
      result.errors.push({ row: 1, message: `Missing required column: ${required}` });
    }
  }
  if (result.errors.length) return result;
  if (rows.length - 1 > 2000) {
    result.errors.push({ row: 0, message: "Import at most 2000 rows at a time." });
    return result;
  }

  type Parsed = {
    slug: string; name: string; sport: string; type: string; version: string; price: number; description: string;
    status: string; pre: boolean; eta: string; image: string; prefix: string; sub: string | null; league: string | null; sizes: readonly string[]; custom: boolean | null; weight: number | null; stock: Record<string, number>;
  };
  const parsed: Parsed[] = [];
  const seenSlugs = new Set<string>();
  const sportSlugs = new Set(await listSportSlugs());
  const sizeSets = new Map(((await db().prepare("SELECT slug, size_set FROM sports").all()) as { slug: string; size_set: string }[]).map((r) => [r.slug, r.size_set]));
  const hasLeague = header.includes("league");
  const subRows = (await db().prepare("SELECT sport_slug, slug, name FROM subcategories").all()) as { sport_slug: string; slug: string; name: string }[];
  const hasSub = header.includes("subcategory");
  const hasCustom = header.includes("customizable");
  const hasWeight = header.includes("weight_g");

  rows.slice(1).forEach((cells, idx) => {
    const rowNo = idx + 2;
    const get = (k: string) => (cells[header.indexOf(k.toLowerCase())] ?? "").trim();
    const err = (m: string) => result.errors.push({ row: rowNo, message: m });
    const slug = get("slug");
    const price = Number(get("price_lkr"));
    const prefix = get("sku_prefix").toUpperCase();
    const status = (get("status") || "published").toLowerCase();
    const stock: Record<string, number> = {};
    let bad = false;
    if (!SLUG.test(slug)) { err("slug must be lowercase letters, numbers and hyphens"); bad = true; }
    if (seenSlugs.has(slug)) { err(`duplicate slug "${slug}" in this file`); bad = true; }
    seenSlugs.add(slug);
    if (!get("name")) { err("name is required"); bad = true; }
    if (!sportSlugs.has(get("sport"))) { err(`sport must be one of: ${[...sportSlugs].join(", ")}`); bad = true; }
    if (!Number.isInteger(price) || price < 0) { err("price_lkr must be a whole number"); bad = true; }
    if (!/^[A-Z0-9-]{2,20}$/.test(prefix)) { err("sku_prefix must be 2 to 20 letters, numbers or hyphens"); bad = true; }
    if (!["published", "draft", "archived"].includes(status)) { err("status must be published, draft or archived"); bad = true; }
    let sub: string | null = null;
    if (hasSub) {
      const v = get("subcategory").toLowerCase();
      if (v === "") sub = "";
      else {
        const m = subRows.find((r) => r.sport_slug === get("sport") && (r.slug === v || r.name.toLowerCase() === v));
        if (!m) { err(`subcategory "${get("subcategory")}" does not exist under ${get("sport")}. Add it in Admin, Categories first`); bad = true; }
        else sub = m.slug;
      }
    }
    let league: string | null = null;
    if (hasLeague) {
      league = get("league").toLowerCase();
      if (league && !sportSlugs.has(league)) { err(`league must be one of: ${[...sportSlugs].join(", ")} (or empty)`); bad = true; }
    }
    const sizes = sizesFor(sizeSets.get(get("sport")) ?? "apparel");
    let weight: number | null = null;
    if (hasWeight && get("weight_g") !== "") {
      weight = Number(get("weight_g"));
      if (!Number.isInteger(weight) || weight < 1 || weight > 20000) { err("weight_g must be a whole number of grams (1 to 20000)"); bad = true; }
    }
    for (const s of sizes) {
      const raw = get(stockColumn(s));
      const n = raw === "" ? 0 : Number(raw);
      if (!Number.isInteger(n) || n < 0) { err(`${stockColumn(s)} must be a whole number of 0 or more`); bad = true; }
      stock[s] = n;
    }
    if (!bad) {
      parsed.push({
        slug, name: get("name"), sport: get("sport"), type: get("type"), version: get("version"), price,
        description: get("description"), status, pre: yes(get("preorder_enabled")), eta: get("preorder_eta"),
        image: get("image_url"), prefix, sub, league, sizes, custom: hasCustom ? yes(get("customizable")) : null, weight, stock,
      });
    }
  });

  // All-or-nothing: if any row is invalid, nothing is written.
  if (result.errors.length) return result;

  try {
  await tx(async (d) => {
    result.created = 0;
    result.updated = 0;
    for (const p of parsed) {
      const existing = (await d.prepare("SELECT id FROM products WHERE slug = ?").get(p.slug)) as { id: number } | undefined;
      let id: number;
      if (existing) {
        id = existing.id;
        await d.prepare(
          `UPDATE products SET name=?, sport_slug=?, type=?, version=?, price_lkr=?, description=?, status=?,
             preorder_enabled=?, preorder_eta=?, image_url=?, is_demo=0 WHERE id=?`,
        ).run(p.name, p.sport, p.type, p.version, p.price, p.description, p.status, p.pre ? 1 : 0, p.eta, p.image, id);
        if (p.sub !== null) await d.prepare("UPDATE products SET subcategory_slug=? WHERE id=?").run(p.sub, id);
        if (p.league !== null) await d.prepare("UPDATE products SET league_slug=? WHERE id=?").run(p.league, id);
        if (p.custom !== null) await d.prepare("UPDATE products SET customizable=? WHERE id=?").run(p.custom ? 1 : 0, id);
        if (p.weight !== null) await d.prepare("UPDATE products SET weight_g=? WHERE id=?").run(p.weight, id);
        result.updated++;
      } else {
        const r = await d
          .prepare(
            `INSERT INTO products (slug,name,sport_slug,type,version,price_lkr,description,status,preorder_enabled,preorder_eta,image_url)
             VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
          )
          .run(p.slug, p.name, p.sport, p.type, p.version, p.price, p.description, p.status, p.pre ? 1 : 0, p.eta, p.image);
        id = r.lastInsertRowid;
        await d.prepare("UPDATE products SET subcategory_slug=?, customizable=?, weight_g=?, league_slug=? WHERE id=?").run(p.sub ?? "", p.custom ? 1 : 0, p.weight ?? 400, p.league ?? "", id);
        result.created++;
      }
      for (const size of p.sizes) {
        const sku = `${p.prefix}-${skuSuffix(size)}`;
        const cur = (await d.prepare("SELECT stock, product_id FROM variants WHERE sku = ?").get(sku)) as { stock: number; product_id: number } | undefined;
        if (cur && cur.product_id !== id) throw new Error(`SKU ${sku} already belongs to another product`);
        if (!cur) {
          await d.prepare("INSERT INTO variants (sku, product_id, size, stock) VALUES (?,?,?,?)").run(sku, id, size, p.stock[size]);
          if (p.stock[size] !== 0) await d.prepare("INSERT INTO inventory_movements (sku, delta, reason) VALUES (?,?, 'import')").run(sku, p.stock[size]);
        } else if (cur.stock !== p.stock[size]) {
          await d.prepare("UPDATE variants SET stock = ? WHERE sku = ?").run(p.stock[size], sku);
          await d.prepare("INSERT INTO inventory_movements (sku, delta, reason) VALUES (?,?, 'import adjustment')").run(sku, p.stock[size] - cur.stock);
        }
      }
    }
  });
  } catch (e) {
    result.created = 0;
    result.updated = 0;
    result.errors.push({ row: 0, message: e instanceof Error ? e.message : "Import failed" });
    return result;
  }
  await audit(actor, "products.import", `${result.created} created, ${result.updated} updated`);
  result.ok = true;
  return result;
}
