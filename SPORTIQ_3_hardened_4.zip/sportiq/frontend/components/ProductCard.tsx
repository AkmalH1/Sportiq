import Link from "next/link";
import type { Product } from "@/lib/types";
import { productBadge } from "@/lib/catalogue";
import { formatLkr } from "@/lib/format";
import { Tilt } from "./Tilt";
import { CapIcon } from "./CapIcon";

export function ProductCard({ product }: { product: Product }) {
  const badge = productBadge(product);
  return (
    <div data-depth><Tilt><article className="group">
      <Link href={`/products/${product.slug}`} className="block">
        <div className="relative aspect-[3/4] overflow-hidden bg-mist">
          {product.imageUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={product.imageUrl} alt={product.name} loading="lazy" decoding="async" width={600} height={800} className="absolute inset-0 h-full w-full object-cover transition duration-700 group-hover:scale-105" />
          ) : product.sportSlug === "caps" ? (
            <CapIcon className="absolute inset-0 m-auto h-1/4 text-line transition duration-500 group-hover:scale-105 group-hover:text-accent" />
          ) : (
            <svg viewBox="0 0 100 120" className="absolute inset-0 m-auto h-1/2 text-line transition duration-500 group-hover:scale-105 group-hover:text-accent" fill="currentColor" aria-hidden="true">
              <path d="M32 10l-24 14 8 22 12-4v68h48V42l12 4 8-22-24-14c-3 8-10 12-18 12s-15-4-18-12z" />
            </svg>
          )}
          <span className={`eyebrow absolute left-0 top-4 px-3 py-1.5 ${badge === "Ready stock" ? "bg-ink text-paper" : badge === "Pre-order" ? "bg-accent text-ink" : "bg-paper text-stone"}`}>
            {badge}
          </span>
          {product.isDemo && <span className="absolute bottom-3 left-3 text-[10px] uppercase tracking-widest text-stone">Demo product</span>}
        </div>
        <h3 className="mt-4 text-sm font-semibold uppercase tracking-wide group-hover:text-accent-dark">{product.name}</h3>
      </Link>
      <p className="mt-1 text-xs text-stone">{product.type} · {product.version}</p>
      <p className="mt-2 text-sm font-semibold">{formatLkr(product.priceLkr)}</p>
    </article></Tilt></div>
  );
}
