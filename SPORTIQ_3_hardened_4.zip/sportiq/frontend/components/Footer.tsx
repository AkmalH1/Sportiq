import Link from "next/link";
import type { Sport } from "@/lib/types";
import { Wordmark } from "./Wordmark";
import { getSettings, whatsappLink } from "@/lib/settings";

export async function Footer({ sports }: { sports: Sport[] }) {
  const s = await getSettings();
  return (
    <footer className="border-t border-line bg-mist">
      <div className="mx-auto grid max-w-[1400px] gap-12 px-4 py-16 lg:grid-cols-[1.4fr_1fr_1fr_1fr] lg:px-10">
        <div>
          <p className="text-5xl"><Wordmark /></p>
          <p className="mt-4 max-w-xs text-sm text-stone">Wear your game. Sportswear sourced for Sri Lanka, in ready stock and pre-order.</p>
          <p className="mt-6 max-w-xs text-xs text-stone">All products are imported A-grade items, not official merchandise. SPORTIQ is not affiliated with or endorsed by any team, league or brand. <Link href="/disclaimer" className="underline">Copyright notice</Link></p>
        </div>
        <FooterCol title="Shop" links={sports.map((s) => [s.name, `/sports/${s.slug}`])} />
        <FooterCol title="Help" links={[
          ["How pre-orders work", "/help/pre-orders"],
          ["Payment methods", "/help/payments"],
          ["Shipping and postage", "/shipping"],
          ["Returns and exchanges", "/returns"],
          ["Copyright notice", "/disclaimer"],
          ["Track an order", "/track-order"],
        ]} />
        <div>
          <FooterCol title="Store" links={[["About us", "/about"], ["Reviews", "/reviews"], ["Cart", "/cart"], ["Search", "/search"], ["Staff login", "/admin"]]} />
          <p className="mt-6 text-sm"><a className="underline hover:text-accent-dark" href={whatsappLink("", s)} target="_blank" rel="noreferrer">WhatsApp {s.phone_display}</a></p>
          {s.address && <p className="mt-2 max-w-[14rem] text-xs text-stone">{s.address}</p>}
        </div>
      </div>
      <div className="border-t border-line py-5 text-center text-xs text-stone">© SPORTIQ. All rights reserved.</div>
    </footer>
  );
}

function FooterCol({ title, links }: { title: string; links: string[][] }) {
  return (
    <div>
      <h2 className="eyebrow text-accent-dark">{title}</h2>
      <ul className="mt-5 space-y-2.5 text-sm">
        {links.map(([label, href]) => (
          <li key={href}><Link href={href} className="hover:text-accent-dark">{label}</Link></li>
        ))}
      </ul>
    </div>
  );
}
