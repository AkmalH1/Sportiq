import Link from "next/link";
import type { Banner } from "@/lib/types";
import { Parallax } from "./Motion";
import { Scene3D } from "./Scene3D";

export function Hero({ banner }: { banner: Banner | undefined }) {
  const b = banner ?? {
    eyebrow: "Sportswear for Sri Lanka", title: "Wear your game.", body: "", ctaLabel: "Shop now", ctaHref: "/shop",
    fromColor: "#111111", toColor: "#f4720a", imageUrl: "",
  };
  const words = b.title.split(" ");
  const last = words.pop();
  return (
    <section className="relative isolate overflow-hidden bg-ink text-paper" style={{ minHeight: "min(92vh, 860px)" }}>
      <div className="absolute inset-0 -z-10" style={{ background: `linear-gradient(120deg, ${b.fromColor} 40%, ${b.toColor} 140%)` }} />
      {b.imageUrl && (
        <Parallax speed={0.25} className="absolute inset-x-0 -top-[15%] -z-10 h-[130%]">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={b.imageUrl} alt="" fetchPriority="high" decoding="async" className="h-full w-full object-cover opacity-60" />
        </Parallax>
      )}
      <Scene3D className="absolute bottom-0 right-0 -z-10 hidden h-[58%] w-[40%] md:-bottom-2 md:block" />
      <Parallax speed={-0.12} className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute right-[18%] top-0 h-[140%] w-px bg-white/25" />
        <div className="absolute right-[34%] top-0 h-[140%] w-px bg-white/10" />
        <div className="absolute left-[8%] top-0 h-[140%] w-px bg-white/10" />
      </Parallax>
      <Parallax speed={0.15} className="pointer-events-none absolute inset-x-0 bottom-0 -z-10 select-none overflow-hidden">
        <p className="display whitespace-nowrap text-[26vw] leading-none text-white/[0.06]" aria-hidden="true">SPORTIQ</p>
      </Parallax>

      <div className="relative mx-auto flex max-w-[1400px] flex-col justify-center px-4 py-16 md:py-24 lg:px-10" style={{ minHeight: "inherit" }}>
        <p className="eyebrow text-accent">{b.eyebrow}</p>
        <h1 className="display relative z-10 mt-6 text-[19vw] md:text-[11rem]">
          {words.join(" ")} <span className="text-accent">{last}</span>
        </h1>
        {b.body && <p className="mt-8 max-w-md text-base text-white/75">{b.body}</p>}
        <div className="mt-10 flex flex-wrap gap-3">
          <Link href={b.ctaHref} className="btn border-accent bg-accent text-ink hover:bg-paper hover:border-paper">{b.ctaLabel}</Link>
          <Link href="/help/pre-orders" className="btn border-white/50 text-paper hover:bg-paper hover:text-ink">How pre-orders work</Link>
        </div>
        <div className="relative mt-10 md:hidden">
          <Scene3D interactive className="mx-auto h-[300px] w-full max-w-[360px]" />
          <p className="eyebrow mt-1 text-center text-white/50">Drag to spin</p>
        </div>
      </div>
    </section>
  );
}
