import Link from "next/link";
import type { Faq, Product, Sport } from "@/lib/types";
import { Parallax, Reveal } from "./Motion";
import { Tilt } from "./Tilt";
import { Coverflow } from "./Coverflow";
import { CapIcon } from "./CapIcon";
import { ProductCard } from "./ProductCard";
import { ReviewList } from "./ReviewList";
import type { Review } from "@/lib/reviews";

export function SectionHead({ id, eyebrow, title, action }: { id: string; eyebrow: string; title: string; action?: React.ReactNode }) {
  return (
    <div className="flex items-end justify-between gap-6 border-b border-line pb-6">
      <div>
        <p className="eyebrow text-accent-dark">{eyebrow}</p>
        <h2 id={id} className="display mt-3 text-4xl md:text-6xl">{title}</h2>
      </div>
      {action}
    </div>
  );
}

export function SportGrid({ sports }: { sports: Sport[] }) {
  return (
    <section className="mx-auto max-w-[1400px] px-4 py-24 lg:px-10" aria-labelledby="sports-h">
      <SectionHead id="sports-h" eyebrow="Shop by sport" title="Choose your arena" />
      <div className="md:hidden">
        <Coverflow label="Sports">
          {[...sports.map((s, i) => (
            <Link key={s.slug} href={`/sports/${s.slug}`} className="relative flex aspect-[3/4] flex-col justify-between overflow-hidden p-5 text-paper shadow-[0_30px_50px_rgba(0,0,0,0.35)]"
              style={{ background: `linear-gradient(165deg, #111111 30%, ${s.accent})` }}>
              <span className="eyebrow text-white/60">0{i + 1}</span>
              <span>
                <span className="display block text-5xl">{s.name}</span>
                <span className="mt-1 block text-xs text-white/70">{s.tagline}</span>
                <span className="eyebrow mt-4 inline-block border-b border-accent pb-1 text-accent">Shop</span>
              </span>
            </Link>
          )),
          <Link key="all" href="/shop" className="flex aspect-[3/4] items-center justify-center border border-ink bg-paper p-5 text-center"><span className="display text-5xl">View<br />all</span></Link>]}
        </Coverflow>
        <p className="eyebrow text-center text-ink/50">Swipe</p>
      </div>
      <ul className="mt-12 hidden grid-cols-2 gap-4 md:grid md:grid-cols-4 md:gap-6">
        {sports.map((s, i) => (
          <li key={s.slug} className={i % 2 === 1 ? "md:mt-12" : ""}>
            <Reveal delay={(i % 4) * 80}>
              <Tilt max={12}>
              <Link href={`/sports/${s.slug}`} className="group relative flex aspect-[3/4] flex-col justify-between overflow-hidden p-5 text-paper"
                style={{ background: `linear-gradient(165deg, #111111 30%, ${s.accent})` }}>
                <span className="eyebrow text-white/60">0{i + 1}</span>
                <span>
                  <span className="display block text-4xl md:text-5xl">{s.name}</span>
                  <span className="mt-1 block text-xs text-white/70">{s.tagline}</span>
                  <span className="eyebrow mt-4 inline-block border-b border-accent pb-1 text-accent transition-all group-hover:pr-4">Shop</span>
                </span>
              </Link>
              </Tilt>
            </Reveal>
          </li>
        ))}
        <li className="md:mt-12">
          <Reveal delay={320}>
            <Link href="/shop" className="group flex aspect-[3/4] items-center justify-center border border-ink p-5 text-center hover:bg-ink hover:text-paper">
              <span className="display text-4xl md:text-5xl">View<br />all</span>
            </Link>
          </Reveal>
        </li>
      </ul>
    </section>
  );
}

export function ManifestoBand() {
  return (
    <section className="relative isolate overflow-hidden bg-accent text-ink">
      <Parallax speed={0.3} className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute -left-20 top-0 h-[120%] w-[40%] -skew-x-12 bg-black/10" />
        <div className="absolute right-[10%] top-0 h-[120%] w-[8%] -skew-x-12 bg-black/10" />
      </Parallax>
      <div className="mx-auto max-w-5xl px-4 py-32 text-center lg:px-10">
        <Reveal>
          <p className="eyebrow">The SPORTIQ manifesto</p>
          <p className="display mt-8 text-5xl md:text-8xl">Sport is identity. Wear the side you are on.</p>
          <p className="mx-auto mt-8 max-w-lg text-base font-medium">
            We bring the shirts, the heritage and the new drops to Sri Lanka, and we tell you honestly what is in stock and what is on its way.
          </p>
        </Reveal>
      </div>
    </section>
  );
}

export function StyleCards({ styles }: { styles: { slug: string; name: string; blurb: string; from: string; to: string }[] }) {
  return (
    <section className="mx-auto max-w-[1400px] px-4 py-24 lg:px-10" aria-labelledby="styles-h">
      <SectionHead id="styles-h" eyebrow="Shop by style" title="Find your look" />
      <ul className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {styles.map((s, i) => (
          <li key={s.slug}>
            <Reveal delay={i * 80}>
              <Tilt max={8}><Link href={`/collections/${s.slug}`} className="group relative flex min-h-72 flex-col justify-end overflow-hidden p-6 text-paper" style={{ background: `linear-gradient(135deg, ${s.from}, ${s.to})` }}>
                <span className="display text-4xl">{s.name}</span>
                <span className="mt-1 text-sm text-white/80">{s.blurb}</span>
              </Link></Tilt>
            </Reveal>
          </li>
        ))}
      </ul>
    </section>
  );
}

export function CapsBand({ caps }: { caps: Product[] }) {
  if (caps.length === 0) return null;
  return (
    <section className="relative isolate overflow-hidden bg-ink text-paper" aria-labelledby="caps-h">
      <Parallax speed={0.2} className="pointer-events-none absolute inset-0 -z-10">
        <CapIcon className="absolute -right-16 -top-10 h-[24rem] w-[42rem] text-white/10" />
      </Parallax>
      <div className="mx-auto max-w-[1400px] px-4 py-24 lg:px-10">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <p className="eyebrow text-accent">Headwear</p>
            <h2 id="caps-h" className="display mt-3 text-6xl md:text-9xl">Top it off.</h2>
          </div>
          <Link href="/caps" className="btn border-accent bg-accent text-ink hover:border-paper hover:bg-paper">Shop all caps</Link>
        </div>
        <ul className="mt-12 grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-4">
          {caps.slice(0, 4).map((p, i) => (
            <li key={p.slug} className="[&_a]:text-paper [&_p]:text-white/70 [&_h3]:text-paper"><Reveal delay={i * 70}><ProductCard product={p} /></Reveal></li>
          ))}
        </ul>
      </div>
    </section>
  );
}

export function LatestDrops({ products }: { products: Product[] }) {
  const demo = products.some((p) => p.isDemo);
  return (
    <section className="bg-mist" aria-labelledby="drops-h">
      <div className="mx-auto max-w-[1400px] px-4 py-24 lg:px-10">
        <SectionHead id="drops-h" eyebrow="New in" title="Latest drops" action={<Link href="/shop" className="eyebrow border-b border-ink pb-1 hover:text-accent-dark">View all</Link>} />
        {demo && <p className="mt-6 inline-block bg-ink px-3 py-1.5 text-[11px] font-semibold uppercase tracking-widest text-paper">Demo products. Replace via Admin, Products, bulk import.</p>}
        <ul className="mt-12 grid grid-cols-2 gap-x-5 gap-y-12 md:grid-cols-3 lg:grid-cols-4">
          {products.slice(0, 8).map((p, i) => (
            <li key={p.slug}><Reveal delay={(i % 4) * 70}><ProductCard product={p} /></Reveal></li>
          ))}
        </ul>
      </div>
    </section>
  );
}

export function PreorderExplainer() {
  return (
    <section className="relative isolate overflow-hidden bg-ink text-paper" aria-labelledby="pre-h">
      <Parallax speed={0.25} className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute -right-40 top-10 h-[30rem] w-[30rem] rounded-full border border-white/10" />
        <div className="absolute -right-20 top-30 h-[22rem] w-[22rem] rounded-full border border-accent/40" />
      </Parallax>
      <div className="mx-auto grid max-w-[1400px] gap-16 px-4 py-28 lg:grid-cols-2 lg:px-10">
        <Reveal>
          <p className="eyebrow text-accent">Pre-orders</p>
          <h2 id="pre-h" className="display mt-4 text-5xl md:text-7xl">Arrives in 2 to 3 weeks. Track every step.</h2>
          <p className="mt-6 max-w-md text-white/70">
            Every size from S to 3XL can be pre-ordered. Full payment is best. In Sri Lanka you can also pay half now and the rest in cash on delivery.
          </p>
          <Link href="/help/pre-orders" className="btn mt-8 border-accent bg-accent text-ink hover:border-paper hover:bg-paper">How it works</Link>
        </Reveal>
        <Reveal delay={120}>
          <ol className="relative border-l border-white/20 pl-8">
            {["Confirmed", "Supplier Paid", "Production", "Shipping", "Arrived in Sri Lanka", "Delivery or pickup"].map((stage, i) => (
              <li key={stage} className="relative pb-6 last:pb-0">
                <span className="absolute -left-[2.45rem] top-1 flex h-4 w-4 items-center justify-center bg-ink">
                  <span className={`h-2.5 w-2.5 rounded-full ${i === 0 ? "bg-accent" : "border border-white/50"}`} />
                </span>
                <p className="eyebrow text-white/50">Step {i + 1}</p>
                <p className="display text-2xl">{stage}</p>
              </li>
            ))}
          </ol>
        </Reveal>
      </div>
    </section>
  );
}

export function Reviews({ reviews }: { reviews: Review[] }) {
  return (
    <section className="mx-auto max-w-[1400px] px-4 py-24 lg:px-10" aria-labelledby="reviews-h">
      <SectionHead id="reviews-h" eyebrow="Customer reviews" title="What fans say" action={<Link href="/reviews" className="eyebrow border-b border-ink pb-1 hover:text-accent-dark">Write a review</Link>} />
      <div className="mt-12"><ReviewList reviews={reviews.slice(0, 6)} /></div>
    </section>
  );
}

export function FaqSection({ faqs }: { faqs: Faq[] }) {
  return (
    <section className="mx-auto max-w-3xl px-4 pb-28 lg:px-10" aria-labelledby="faq-h">
      <SectionHead id="faq-h" eyebrow="FAQ" title="Good questions" />
      <div className="divide-y divide-line border-b border-line">
        {faqs.map((f) => (
          <details key={f.q} className="group py-5">
            <summary className="flex cursor-pointer items-center justify-between gap-6 text-sm font-semibold uppercase tracking-wide">
              {f.q}
              <span className="text-xl font-light text-accent transition group-open:rotate-45" aria-hidden="true">+</span>
            </summary>
            <p className="mt-4 max-w-xl text-sm leading-relaxed text-stone">{f.a}</p>
          </details>
        ))}
      </div>
    </section>
  );
}
