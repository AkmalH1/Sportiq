# End-to-end tests (Playwright for Python)
`pip install playwright && playwright install chromium`
Start a FRESH server first (`rm -rf data`, then `npm run build && npm start -- -p 3077` with `ADMIN_PASSWORD_HASH=$(node scripts/hash-password.mjs test-password-12345) ADMIN_MFA_OPTIONAL=true SESSION_SECRET=testsecret1234567890-abcdefghijkl BANK_NAME=TestBank BANK_ACCOUNT_NAME=SPORTIQ BANK_ACCOUNT_NUMBER=123456`), then run `python3 tests/e2e/e2e2.py`, `e2e3.py`, `e2e4.py`.
`e2e5.py` and `e2e6.py` (PayHere, late payments, lockout) need a fresh server on port 3078 with `PAYHERE_MERCHANT_ID=1200001 PAYHERE_MERCHANT_SECRET=testsecret`.
`audit.py <product-slug>` checks horizontal overflow at 320/375/390/768/1440px and small touch targets.
Each script prints PASS/FAIL lines; any FAIL is a bug.

New suites: `e2e9.py` (PayHere independent verification against a mock Retrieval API; run with `bash tests/e2e/run-e2e9.sh`), `e2e10.py` (authenticator-code login, replay, no lockout DoS; `bash tests/e2e/run-e2e10.sh`), `csp.py` (strict nonce CSP, real policy enforced), `tests/unit/ratelimit.concurrency.mjs` (200 simultaneous requests against the atomic limiter; needs the database), `node --experimental-strip-types --test tests/unit/*.test.ts` (TOTP vectors).
`ADMIN_MFA_OPTIONAL=true` exists ONLY so throwaway test servers can log in without an authenticator. Never set it on a live server.
