import { listBanners, listProducts } from "@/lib/catalogue";
import { listCollections, listFaqs } from "@/lib/content";
import { listApproved } from "@/lib/reviews";
import { listSports } from "@/lib/categories";
import { CampaignSlider } from "@/components/CampaignSlider";
import { Hero } from "@/components/Hero";
import { FaqSection, CapsBand, LatestDrops, ManifestoBand, PreorderExplainer, Reviews, SportGrid, StyleCards } from "@/components/Sections";

export const dynamic = "force-dynamic";

export default async function Home() {
  const hero = (await listBanners("hero"))[0];
  const slides = await listBanners("slider");
  const products = await listProducts();
  const sports = await listSports();
  const styles = await listCollections();
  const faqs = await listFaqs();
  return (
    <>
      <Hero banner={hero} />
      <SportGrid sports={sports} />
      <CampaignSlider slides={slides} />
      <ManifestoBand />
      <StyleCards styles={styles} />
      <CapsBand caps={await listProducts({ sport: "caps" })} />
      <LatestDrops products={products} />
      <PreorderExplainer />
      <Reviews reviews={await listApproved({ limit: 6 })} />
      <FaqSection faqs={faqs} />
    </>
  );
}
