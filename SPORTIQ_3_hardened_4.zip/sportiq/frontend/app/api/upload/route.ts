import { NextResponse } from "next/server";
import { clientIp, limited } from "@/lib/ratelimit";
import { saveImage } from "@/lib/upload";

export const dynamic = "force-dynamic";

/** Public image upload for customers (jersey customisation images, review photos, exchange photos). */
export async function POST(req: Request) {
  if (await limited("upload:" + clientIp(req.headers), 15, 10 * 60 * 1000)) {
    return NextResponse.json({ error: "Too many uploads. Please wait a few minutes." }, { status: 429 });
  }
  // Global ceiling so many addresses together cannot fill the disk (each stored image is at most ~1600px WebP; 15 per address per 10 min is the real per-visitor limit).
  if (await limited("upload-all", 2000, 60 * 60 * 1000)) {
    return NextResponse.json({ error: "Uploads are busy right now. Please try again later." }, { status: 429 });
  }
  if (Number(req.headers.get("content-length") ?? 0) > 5 * 1024 * 1024) {
    return NextResponse.json({ error: "Image is larger than 4 MB." }, { status: 413 });
  }
  try {
    const fd = await req.formData();
    const file = fd.get("file");
    if (!(file instanceof File)) return NextResponse.json({ error: "Choose an image." }, { status: 400 });
    return NextResponse.json({ url: await saveImage(file) });
  } catch (e) {
    return NextResponse.json({ error: e instanceof Error ? e.message : "Upload failed." }, { status: 400 });
  }
}
