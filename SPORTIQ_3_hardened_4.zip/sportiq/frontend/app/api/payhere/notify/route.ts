import { db, tx } from "@/lib/db";
import { addReconciliation, creditPayment, failPayment, type PaymentRow } from "@/lib/orders";
import { clientIp, limited } from "@/lib/ratelimit";
import { notifySignature, payhereAmount, payhereConfig, safeEqual } from "@/lib/payhere";
import { verifyConfigured, verifyPayHerePayment } from "@/lib/payhere-verify";
import { flagUnverified } from "@/lib/payhere-retry";

export const dynamic = "force-dynamic";

/** Only the fields needed to investigate a payment are stored. The signature and merchant secret never are. */
async function log(orderId: string | null, payload: Record<string, string>, outcome: string, paymentId: number | null = null) {
  const safe = { ...payload };
  delete safe.md5sig;
  await db().prepare("INSERT INTO payment_events (provider, provider_order_id, payload, outcome, payment_id) VALUES ('payhere', ?, ?, ?, ?)")
    .run(orderId, JSON.stringify(safe).slice(0, 2000), outcome, paymentId);
}

export async function POST(req: Request) {
  const cfg = payhereConfig();
  // A genuine notification is a tiny form post. Refuse anything large, and slow down floods before doing any work.
  if (Number(req.headers.get("content-length") ?? 0) > 4096) return new Response("Too large", { status: 413 });
  if (await limited("notify:" + clientIp(req.headers), 240, 60 * 1000)) return new Response("Too many requests", { status: 429 });
  let form: FormData;
  try {
    form = await req.formData();
  } catch {
    return new Response("Bad request", { status: 400 });
  }
  const get = (k: string) => String(form.get(k) ?? "").slice(0, 200);
  const p = {
    merchant_id: get("merchant_id"),
    order_id: get("order_id"),
    payment_id: get("payment_id"),
    payhere_amount: get("payhere_amount"),
    payhere_currency: get("payhere_currency"),
    status_code: get("status_code"),
    md5sig: get("md5sig"),
  };

  if (!cfg.configured) {
    await log(p.order_id, p, "rejected: not configured");
    return new Response("Not configured", { status: 503 });
  }
  const expected = notifySignature(p, cfg.secret);
  if (p.merchant_id !== cfg.merchantId || !safeEqual(expected, p.md5sig.toUpperCase())) {
    await log(p.order_id, p, "rejected: bad signature");
    return new Response("Invalid signature", { status: 400 });
  }

  const pay = (await db().prepare("SELECT * FROM payments WHERE provider_order_id = ? AND provider = 'payhere'").get(p.order_id)) as PaymentRow | undefined;
  if (!pay) {
    await log(p.order_id, p, "rejected: unknown order");
    return new Response("Unknown order", { status: 404 });
  }
  // The stored, server-calculated amount and currency must match what the gateway reports.
  if (p.payhere_amount !== payhereAmount(pay.amount) || p.payhere_currency !== pay.currency) {
    await log(p.order_id, p, "rejected: amount or currency mismatch", pay.id);
    // The signature was valid, so money may really have moved for a different amount. Staff must look at it.
    await tx(async (d) => {
      // The gateway retries notifications, so open one review item per payment, not one per retry.
      const dup = await d.prepare("SELECT 1 FROM reconciliation_items WHERE payment_id = ? AND kind = 'amount_mismatch' AND status = 'open'").get(pay.id);
      if (!dup) await addReconciliation(d, pay.order_id, pay.id, "amount_mismatch", Math.round(Number(p.payhere_amount)) || 0,
        `PayHere reported ${p.payhere_amount} ${p.payhere_currency} for ${pay.provider_order_id} but ${payhereAmount(pay.amount)} ${pay.currency} was expected. Not credited.`);
    });
    return new Response("Amount mismatch", { status: 400 });
  }

  switch (p.status_code) {
    case "2": {
      // Second, independent check: ask PayHere's own Retrieval API whether this payment really exists and was RECEIVED for this
      // amount. A forged or replayed notification cannot pass this even if the signature were somehow known.
      let source = "";
      if (verifyConfigured()) {
        const v = await verifyPayHerePayment(pay.provider_order_id, pay.amount, pay.currency, p.payment_id);
        if (v.state === "rejected") {
          await log(p.order_id, p, "rejected: not confirmed by PayHere", pay.id);
          await flagUnverified(pay, v.reason);
          return new Response("Not confirmed", { status: 400 });
        }
        if (v.state === "unavailable") {
          // Never credit on a guess. A background job re-checks this payment; a 503 also lets PayHere resend.
          await log(p.order_id, p, "verification unavailable", pay.id);
          return new Response("Verification unavailable", { status: 503 });
        }
        source = "notify+retrieval";
      }
      let credited = false;
      try {
        credited = await creditPayment(pay.id, p.payment_id || null, "payhere", source);
      } catch (e) {
        // The same gateway payment id was already used on another payment: never credit twice, just acknowledge.
        if ((e as { errno?: number }).errno !== 1062) throw e;
      }
      await log(p.order_id, p, credited ? "credited" : "duplicate ignored", pay.id);
      break;
    }
    case "0":
      await log(p.order_id, p, "pending", pay.id);
      break;
    case "-1":
      await failPayment(pay.id, "cancelled", "Cancelled at gateway");
      await log(p.order_id, p, "cancelled", pay.id);
      break;
    case "-2":
      await failPayment(pay.id, "failed", "Failed at gateway");
      await log(p.order_id, p, "failed", pay.id);
      break;
    case "-3":
      await failPayment(pay.id, "chargeback", "Charged back");
      await log(p.order_id, p, "chargeback", pay.id);
      break;
    default:
      await log(p.order_id, p, "unknown status", pay.id);
  }
  return new Response("OK", { status: 200 });
}
