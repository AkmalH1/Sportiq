"use client";

import { useActionState } from "react";
import { importCsvAction, type ImportState } from "../actions";

export function ImportForm() {
  const [res, action, pending] = useActionState<ImportState, FormData>(importCsvAction, null);
  return (
    <form action={action} className="mt-8 grid max-w-xl gap-4">
      <label><span className="eyebrow mb-2 block text-stone">CSV file</span><input type="file" name="file" accept=".csv,text/csv" required className="field" /></label>
      <button className="btn btn-primary w-fit" disabled={pending}>{pending ? "Importing…" : "Validate and import"}</button>
      {res?.ok && <p role="status" className="border-l-2 border-accent bg-mist p-4 text-sm">Imported. {res.created} created, {res.updated} updated.</p>}
      {res && !res.ok && (
        <div role="alert" className="border-l-2 border-red-600 bg-red-50 p-4 text-sm text-red-800">
          <p className="font-semibold">Nothing was imported. Fix these and upload again:</p>
          <ul className="mt-2 list-disc pl-5">
            {res.errors.slice(0, 50).map((e, i) => <li key={i}>{e.row ? `Row ${e.row}: ` : ""}{e.message}</li>)}
          </ul>
          {res.errors.length > 50 && <p className="mt-2">…and {res.errors.length - 50} more.</p>}
        </div>
      )}
    </form>
  );
}
