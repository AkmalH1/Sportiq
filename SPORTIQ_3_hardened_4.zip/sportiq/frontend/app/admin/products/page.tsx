import Link from "next/link";
import { requireAdmin } from "@/lib/admin-auth";
import { listProducts } from "@/lib/catalogue";
import { SIZES } from "@/lib/config";
import { formatLkr } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function AdminProducts() {
  await requireAdmin();
  const products = await listProducts({ includeUnpublished: true });
  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <h1 className="display text-5xl">Products</h1>
        <div className="flex gap-3">
          <Link href="/admin/import" className="btn btn-ghost">Bulk import</Link>
          <Link href="/admin/products/new" className="btn btn-primary">Add product</Link>
        </div>
      </div>
      <div className="mt-8 overflow-x-auto">
        <table className="w-full min-w-[800px] text-left text-sm">
          <thead className="eyebrow border-b border-line text-stone">
            <tr><th className="py-3 pr-4">Product</th><th className="pr-4">Price</th><th className="pr-4">Status</th><th className="pr-4">Pre-order</th>{SIZES.map((s) => <th key={s} className="pr-3">{s}</th>)}<th className="pr-3">One</th></tr>
          </thead>
          <tbody className="divide-y divide-line">
            {products.map((p) => (
              <tr key={p.id}>
                <td className="py-3 pr-4"><Link href={`/admin/products/${p.slug}`} className="font-semibold underline">{p.name}</Link><div className="text-xs text-stone">{p.sportSlug}{p.isDemo ? " · demo" : ""}</div></td>
                <td className="pr-4">{formatLkr(p.priceLkr)}</td>
                <td className="pr-4">{p.status}</td>
                <td className="pr-4">{p.preorderEnabled ? "Yes" : "No"}</td>
                {SIZES.map((s) => <td key={s} className="pr-3">{p.variants.find((v) => v.size === s)?.stock ?? "-"}</td>)}
                <td className="pr-3">{p.variants.find((v) => v.size === "One Size")?.stock ?? "-"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
