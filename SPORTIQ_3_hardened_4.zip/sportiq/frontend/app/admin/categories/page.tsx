import { Flash } from "@/components/AdminBits";
import { Hint } from "@/components/AdminUI";
import { requireAdmin } from "@/lib/admin-auth";
import { listSportsAdmin } from "@/lib/categories";
import { addSportAction, addSubAction, deleteSportAction, deleteSubAction, saveSportAction, saveSubAction } from "../ops-actions";

export const dynamic = "force-dynamic";

export default async function Categories({ searchParams }: { searchParams: Promise<{ ok?: string; err?: string }> }) {
  await requireAdmin();
  const sp = await searchParams;
  const sports = await listSportsAdmin();
  return (
    <div>
      <h1 className="display text-5xl">Categories</h1>
      <Hint>Categories are the sports in the menu and on the homepage. Rename them, change the order, hide them, or add new ones. Subcategories sit inside each category. Each category or subcategory can have its own size chart, shown as a Size chart button on every product in it. Hidden categories disappear from the site but keep their products.</Hint>
      <div className="mt-6"><Flash ok={sp.ok} err={sp.err} /></div>
      <div className="space-y-4">
        {sports.map((s) => (
          <details key={s.slug} className="border border-line">
            <summary className="flex cursor-pointer items-center justify-between p-4">
              <span><strong>{s.name}</strong> <span className="text-xs text-stone">/{s.slug}</span>{!s.active && <span className="ml-3 text-xs text-stone">hidden</span>}</span>
              <span className="text-xs text-stone">{s.subs.length} subcategories · Edit</span>
            </summary>
            <div className="space-y-8 border-t border-line p-4">
              <form action={saveSportAction} className="grid gap-3 sm:grid-cols-[1fr_1fr_6rem_6rem_auto] sm:items-end">
                <input type="hidden" name="slug" value={s.slug} />
                <label><span className="eyebrow mb-2 block text-stone">Name</span><input name="name" defaultValue={s.name} required className="field" /></label>
                <label><span className="eyebrow mb-2 block text-stone">Tagline</span><input name="tagline" defaultValue={s.tagline} className="field" /></label>
                <label><span className="eyebrow mb-2 block text-stone">Colour</span><input name="accent" defaultValue={s.accent} className="field" /></label>
                <label><span className="eyebrow mb-2 block text-stone">Order</span><input name="sort" type="number" defaultValue={s.sort} className="field" /></label>
                <div className="flex items-center gap-3"><label className="flex items-center gap-2 text-sm"><input type="checkbox" name="active" defaultChecked={s.active} /> Show</label><button className="btn btn-primary">Save</button></div>
                <label className="sm:col-span-5"><span className="eyebrow mb-2 block text-stone">Size chart for the whole category (optional, used when a subcategory has none)</span><textarea name="size_chart" rows={4} defaultValue={s.sizeChart} placeholder={"Size,Chest (cm),Length (cm)\nS,96,68\nM,102,70"} className="field font-mono text-xs" /></label>
              </form>

              <div>
                <p className="eyebrow">Subcategories</p>
                <ul className="mt-3 space-y-2">
                  {s.subs.map((c) => (
                    <li key={c.id} className="flex flex-wrap items-center gap-3">
                      <form action={saveSubAction} className="flex w-full flex-wrap items-start gap-3 border-l-2 border-line pl-3">
                        <input type="hidden" name="id" value={c.id} />
                        <input name="name" defaultValue={c.name} required className="field w-52" aria-label="Subcategory name" />
                        <input name="sort" type="number" defaultValue={c.sort} className="field w-20" aria-label="Order" />
                        <label className="flex h-12 items-center gap-2 text-sm"><input type="checkbox" name="active" defaultChecked={c.active} /> Show</label>
                        <button className="btn btn-ghost !px-4 !py-2 text-xs">Save</button>
                        <details className="w-full"><summary className="cursor-pointer text-xs underline text-stone">Size chart{c.sizeChart ? " (set)" : ""}</summary>
                          <textarea name="size_chart" rows={5} defaultValue={c.sizeChart} placeholder={"Size,Chest (cm),Length (cm)\nS,96,68\nM,102,70\n# Note shown under the table"} className="field mt-2 font-mono text-xs" />
                        </details>
                      </form>
                      <form action={deleteSubAction}><input type="hidden" name="id" value={c.id} /><button className="text-xs underline text-stone">Delete</button></form>
                    </li>
                  ))}
                </ul>
                <form action={addSubAction} className="mt-4 flex gap-3">
                  <input type="hidden" name="sport" value={s.slug} />
                  <input name="name" required placeholder="New subcategory name" className="field max-w-xs" aria-label="New subcategory" />
                  <button className="btn btn-ghost">Add</button>
                </form>
              </div>
              <form action={deleteSportAction}><input type="hidden" name="slug" value={s.slug} /><button className="text-xs underline text-stone">Delete this category (only if it has no products)</button></form>
            </div>
          </details>
        ))}
      </div>
      <h2 className="eyebrow mt-10">Add a category</h2>
      <form action={addSportAction} className="mt-4 flex gap-3">
        <input name="name" required placeholder="e.g. Cricket" className="field max-w-xs" aria-label="New category" />
        <button className="btn btn-primary">Add category</button>
      </form>
    </div>
  );
}
