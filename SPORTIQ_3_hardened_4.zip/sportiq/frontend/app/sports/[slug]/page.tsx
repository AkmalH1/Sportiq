import type { Metadata } from "next";
import { notFound, redirect } from "next/navigation";
import { Suspense } from "react";
import { PageShell } from "@/components/PageShell";
import { ProductGrid } from "@/components/ProductGrid";
import { listProducts } from "@/lib/catalogue";
import Link from "next/link";
import { getSport, listSportsAdmin } from "@/lib/categories";

export const dynamic = "force-dynamic";
type Props = { params: Promise<{ slug: string }>; searchParams: Promise<{ type?: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  return { title: (await getSport(slug))?.name ?? "Sport" };
}

async function Inner({ params, searchParams }: Props) {
  const { slug } = await params;
  const { type } = await searchParams;
  if (slug === "caps") redirect(type ? `/caps?style=${encodeURIComponent(type)}` : "/caps");
  const sport = await getSport(slug);
  if (!sport) notFound();
  const subs = (await listSportsAdmin()).find((s) => s.slug === slug)?.subs.filter((c) => c.active) ?? [];
  const active = subs.find((c) => c.name === type || c.slug === type);
  return (
    <PageShell eyebrow={sport.tagline} title={sport.name}>
      {subs.length > 0 && (
        <nav aria-label="Subcategories" className="-mt-4 mb-10 flex flex-wrap gap-2">
          <Link href={`/sports/${slug}`} className={`eyebrow inline-flex min-h-11 items-center border px-4 py-2 ${!active ? "border-ink bg-ink text-paper" : "border-line hover:border-ink"}`}>All</Link>
          {subs.map((c) => (
            <Link key={c.id} href={`/sports/${slug}?type=${encodeURIComponent(c.slug)}`} className={`eyebrow inline-flex min-h-11 items-center border px-4 py-2 ${active?.id === c.id ? "border-ink bg-ink text-paper" : "border-line hover:border-ink"}`}>{c.name}</Link>
          ))}
        </nav>
      )}
      <ProductGrid products={await listProducts({ sport: slug, sub: active?.slug })} />
    </PageShell>
  );
}

export default function SportPage(props: Props) {
  return <Suspense fallback={<div className="mx-auto max-w-[1400px] px-4 py-16"><div className="h-20 w-2/3 animate-pulse bg-mist" /></div>}><Inner {...props} /></Suspense>;
}
