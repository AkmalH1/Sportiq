import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { Suspense } from "react";
import { PageShell } from "@/components/PageShell";
import { ProductPurchase } from "@/components/ProductPurchase";
import { getProductBySlug, sizeStates } from "@/lib/catalogue";
import { formatLkr } from "@/lib/format";
import { getSettings, optionPrices } from "@/lib/settings";
import Link from "next/link";
import { chartFor } from "@/lib/sizechart-server";
import { ReviewList } from "@/components/ReviewList";
import { listApproved } from "@/lib/reviews";

export const dynamic = "force-dynamic";
type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const p = await getProductBySlug(slug);
  return { title: p ? p.name : "Product", description: p?.description || undefined };
}

async function Inner({ params }: Props) {
  const { slug } = await params;
  const p = await getProductBySlug(slug);
  if (!p) notFound();
  return (
    <PageShell eyebrow={`${p.type} · ${p.version}`} title={p.name}>
      <div className="grid gap-12 md:grid-cols-2 lg:gap-20">
        <div className="relative flex aspect-[3/4] items-center justify-center overflow-hidden bg-mist">
          {p.imageUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={p.imageUrl} alt={p.name} fetchPriority="high" decoding="async" width={900} height={1200} className="h-full w-full object-cover" />
          ) : (
            <svg viewBox="0 0 100 120" className="h-1/2 text-line" fill="currentColor" aria-hidden="true">
              <path d="M32 10l-24 14 8 22 12-4v68h48V42l12 4 8-22-24-14c-3 8-10 12-18 12s-15-4-18-12z" />
            </svg>
          )}
          {p.isDemo && <span className="eyebrow absolute left-0 top-4 bg-ink px-3 py-1.5 text-paper">Demo product</span>}
        </div>
        {p.gallery.length > 0 && (
          <ul className="grid grid-cols-3 gap-2 md:col-start-1">
            {p.gallery.map((u) => (
              // eslint-disable-next-line @next/next/no-img-element
              <li key={u}><img src={u} alt={`${p.name} photo`} className="aspect-square w-full object-cover" loading="lazy" decoding="async" width={600} height={600} /></li>
            ))}
          </ul>
        )}
        <div className="md:pt-6">
          <p className="text-3xl font-semibold">{formatLkr(p.priceLkr)}</p>
          {p.description && <p className="mt-4 max-w-md text-sm leading-relaxed text-stone">{p.description}</p>}
          <p className="mt-6 max-w-md border-l-2 border-line pl-3 text-xs text-stone">Imported A-grade fan-version product. Not official or licensed merchandise, and not endorsed by any team, league or brand. <Link href="/disclaimer" className="underline">Copyright notice</Link></p>
          <div className="mt-10">
            <ProductPurchase slug={p.slug} name={p.name} price={p.priceLkr} sizes={sizeStates(p)} preorderEnabled={p.preorderEnabled} eta={p.preorderEta} customizable={p.customizable} prices={optionPrices(await getSettings())} chart={await chartFor(p.sportSlug, p.subcategorySlug)} />
          </div>
        </div>
      </div>
      <section className="mt-24" aria-labelledby="rev-h">
        <div className="flex items-end justify-between gap-6 border-b border-line pb-4">
          <h2 id="rev-h" className="display text-4xl">Reviews</h2>
          <Link href={`/reviews?product=${p.slug}`} className="eyebrow inline-flex min-h-11 items-center border-b border-ink hover:text-accent-dark">Write a review</Link>
        </div>
        <div className="mt-8"><ReviewList reviews={await listApproved({ product: p.slug, limit: 6 })} /></div>
      </section>
    </PageShell>
  );
}

export default async function ProductPage(props: Props) {
  // Check the product exists before streaming starts so an unknown slug returns a real 404.
  if (!(await getProductBySlug((await props.params).slug))) notFound();
  return (
    <Suspense fallback={<div className="mx-auto max-w-[1400px] px-4 py-16"><div className="h-20 w-2/3 animate-pulse bg-mist" /></div>}>
      <Inner {...props} />
    </Suspense>
  );
}
